#pragma once
#include <memory>
#include <string>

using namespace std;

struct Compression {

    static string decompress(const string& inFilePath, size_t maxBytes = 1000000000);
    static shared_ptr<ifstream> decompress(const string& inFilePath, const string& outFilePath, bool asText = true, size_t maxBytes = 1000000000);
};
