#pragma once

#include <spdlog/spdlog.h>

using namespace std;

struct LoggingSetup {
    static void SetupDefaultLogging(const string& logPath = "logs/log", int maxFileSize = 1024 * 1024, int maxFiles = 3);
};
