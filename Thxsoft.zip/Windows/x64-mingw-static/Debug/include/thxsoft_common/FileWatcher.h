#pragma once
#include <filesystem>
#include <chrono>
#include <functional>
#include <thread>
#include <unordered_map>

namespace thxsoft::common
{
    enum class FileStatus { created, modified, erased };

    struct FileWatcher
    {
        explicit FileWatcher(const std::filesystem::path& pathToWatch, std::chrono::duration<int, std::milli> delay);
        [[nodiscard]] std::thread start(const std::function<void(std::string, FileStatus)>& action);

    private:
        void dispatch();

        std::function<void(std::string, FileStatus)> _action;
        std::filesystem::path _pathToWatch;
        std::chrono::duration<int, std::milli> _delay;
        std::unordered_map<std::string, std::filesystem::file_time_type> _paths;
    };
}
