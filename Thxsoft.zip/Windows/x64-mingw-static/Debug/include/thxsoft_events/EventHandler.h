#pragma once
#include <functional>
#include <iostream>
#include <memory>
#include <utility>
#include "EventArgs.h"

namespace thxsoft::events
{
    class EventHandler {
    public:
        using Func = std::function<void(const std::shared_ptr<EventArgs>&)>;

    private:
        Func _callback_func;
        std::shared_ptr<EventArgs> _args;

    public:
        EventHandler() : _args(nullptr)
        {
        }

        explicit EventHandler(Func callback_func) : _callback_func{std::move(callback_func)}, _args()
        {
        }

        void operator()(const std::shared_ptr<EventArgs>& args) const;
        void operator=(const EventHandler& callback_func);
        bool operator!=(std::nullptr_t) const;

        void setEventArgs(const std::shared_ptr<EventArgs>& args);
        [[nodiscard]] std::shared_ptr<EventArgs> getEventArgs() const;
    };
}