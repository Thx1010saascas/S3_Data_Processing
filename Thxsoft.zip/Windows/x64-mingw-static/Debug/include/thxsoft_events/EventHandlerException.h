#pragma once
#include <exception>

namespace thxsoft::events
{
    class EventHandlerException final : public std::exception
    {
        const char* _message;

    public:
        explicit EventHandlerException(const char* message);

        [[nodiscard]] const char* what() const noexcept override;
     };
}