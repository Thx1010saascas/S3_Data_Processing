#pragma once
#include <string>

namespace thxsoft::events
{
    class EventArgs
    {
        std::string _model;

    public:
        EventArgs() = default;
        explicit EventArgs(std::string model)
            : _model(std::move(model))
        {
        }

        virtual ~EventArgs() = default;

        [[nodiscard]] std::string model() const { return _model; };
};
}