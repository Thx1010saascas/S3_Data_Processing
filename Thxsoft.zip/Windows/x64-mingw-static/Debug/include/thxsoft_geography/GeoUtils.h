#pragma once
#include <memory>
#include <optional>
#include <string>

namespace thxsoft::geography
{
    enum DistanceUnits
    {
        Feet,
        Meters,
        NauticalMiles
    };

    struct WindDirection
    {
        explicit WindDirection(const int directionMagnetic, const int speed)
          : _directionMagnetic(directionMagnetic), _speedKnots(speed)
        {
        }

        int directionMagnetic() const { return _directionMagnetic; };
        int speedKnots() const { return _speedKnots; };

    private:
        const int _directionMagnetic;
        const int _speedKnots;
    };

    struct CrossWind
    {
        explicit CrossWind(const int crosswindKnots, const int headwindKnots)
        : _crosswindKnots(crosswindKnots), _headwindKnots(headwindKnots)
        {
        }

        int crosswindKnots() const { return _crosswindKnots; };
        int headwindKnots() const { return _headwindKnots; };

    private:
        int _crosswindKnots;
        int _headwindKnots;
    };

#define PI              3.141592653589793238
#define Degrees2Radians 0.017453292519943296
#define Radians2Degrees 57.295779513082321

    struct GeoUtils
    {
        static CrossWind getCrosswind(int aircraftHeadingMegnetic, const WindDirection& wind);
        static double getDistanceFast(double longitude, double latitude, double otherLongitude, double otherLatitude, const DistanceUnits& distanceUnit = Meters);
        static double getDistance(double longitude1, double latitude1, double longitude2, double latitude2, const DistanceUnits& distanceUnit = Meters);
        static double getBearing(double bearing1, double bearing2);
        static double getBearing(double longitude1, double latitude1, double longitude2, double latitude2);
        static double dmsToDecimal(const std::string& dms);
    };
}
