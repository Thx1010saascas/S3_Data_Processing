#pragma once
#include <functional>
#include <memory>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct FacSubDefinition
    {
        explicit FacSubDefinition(const SIMCONNECT_FACILITY_LIST_TYPE facilityType, const SIMCONNECT_DATA_REQUEST_ID inRangeRequestId, const SIMCONNECT_DATA_REQUEST_ID outOfRangeRequestId,
                                  std::function<void(SIMCONNECT_FACILITY_LIST_TYPE, const SIMCONNECT_RECV_FACILITIES_LIST*)> callback)
            : facilityType(facilityType), inRangeRequestId(inRangeRequestId), outOfRangeRequestId(outOfRangeRequestId), callback(move(callback))
        {
        }

        const SIMCONNECT_FACILITY_LIST_TYPE facilityType;
        const SIMCONNECT_DATA_REQUEST_ID inRangeRequestId;
        const SIMCONNECT_DATA_REQUEST_ID outOfRangeRequestId;
        std::function<void(SIMCONNECT_FACILITY_LIST_TYPE facilityType, const SIMCONNECT_RECV_FACILITIES_LIST*)> callback;

        void setCallback(const std::function<void(SIMCONNECT_FACILITY_LIST_TYPE facilityType, const SIMCONNECT_RECV_FACILITIES_LIST*)>& cb)
        {
            callback = cb;
        }
    };

    struct FacilitySubscriptionBuilder
    {
        explicit FacilitySubscriptionBuilder(HANDLE simConnect, std::vector<std::shared_ptr<FacSubDefinition>>& facSubDefinitions);

        FacilitySubscriptionBuilder* setCallback(const std::function<void(SIMCONNECT_FACILITY_LIST_TYPE facilityType, const SIMCONNECT_RECV_FACILITIES_LIST*)>& callback);
        FacilitySubscriptionBuilder* add(SIMCONNECT_FACILITY_LIST_TYPE facilityType, SIMCONNECT_DATA_REQUEST_ID inRangeRequestId, SIMCONNECT_DATA_REQUEST_ID outOfRangeRequestId = -1);
        FacilitySubscriptionBuilder* erase(SIMCONNECT_FACILITY_LIST_TYPE facilityType);

    private:
        HANDLE _simConnect;
        std::vector<std::shared_ptr<FacSubDefinition>>& _facSubDefinitions;
    };
}
