﻿#pragma once

namespace thxsoft::simconnect
{
    enum SimConnectEventIds
    {
        ZuluDays,
        ZuluHours,
        ZuluMinutes,
        Seconds,
        SimStop,
        SimStart
    };

    enum SimConnectEventGroups
    {
        ZuluDate
    };
}