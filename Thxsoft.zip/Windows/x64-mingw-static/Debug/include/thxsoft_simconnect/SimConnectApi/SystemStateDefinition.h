#pragma once
#include <functional>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct SystemStateDefinition
    {
        explicit SystemStateDefinition(const DWORD requestId, const char* state, std::function<void(const SIMCONNECT_RECV_SYSTEM_STATE*)> callback)
            : _requestId(requestId), _state(state), _callback(move(callback)) { }

        [[nodiscard]] DWORD requestId() const;
        [[nodiscard]] std::function<void(const SIMCONNECT_RECV_SYSTEM_STATE*)>& callback();
        [[nodiscard]] const char* state() const;
        void setCallback(const std::function<void(const SIMCONNECT_RECV_SYSTEM_STATE*)>& cb);

    private:
        DWORD _requestId;
        const char* _state;
        std::function<void(const SIMCONNECT_RECV_SYSTEM_STATE*)> _callback;
    };
};
