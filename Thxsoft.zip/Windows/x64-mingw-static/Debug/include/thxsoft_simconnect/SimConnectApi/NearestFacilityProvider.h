#pragma once
#include "FacilitySubscriptionBuilder.h"
#include "Models/NearestFacilities.h"

namespace thxsoft::simconnect
{
    struct NearestFacilityCacheEntry
    {
        std::string Ident;
        std::string Region;
        double Latitude;
        double Longitude;
        double Altitude;
    };

    struct NearestFacilityRecord
    {
        explicit NearestFacilityRecord(const SIMCONNECT_FACILITY_LIST_TYPE facilityType)
            : _inDefineId(DWORD_MAX - 1 - (facilityType * 2)), _outDefineId(DWORD_MAX - 2 - (facilityType * 2)), _facilityType(facilityType)
        {
        }

        DWORD getInDefineId() const { return _inDefineId; }
        DWORD getOutDefineId() const { return _outDefineId; }
        SIMCONNECT_FACILITY_LIST_TYPE getFacilityType() const { return _facilityType; }
        [[nodiscard]] std::vector<std::shared_ptr<NearestFacilityCacheEntry>>& nearestData() { return _nearestData; }

    private:
        DWORD _inDefineId;
        DWORD _outDefineId;
        SIMCONNECT_FACILITY_LIST_TYPE _facilityType;
        std::vector<std::shared_ptr<NearestFacilityCacheEntry>> _nearestData = std::vector<std::shared_ptr<NearestFacilityCacheEntry>>();
    };

    struct NearestFacilityProvider
    {
        explicit NearestFacilityProvider(HANDLE simConnect, const std::shared_ptr<FacilitySubscriptionBuilder>& facilitySubscriptionBuilder);

        [[nodiscard]] std::shared_ptr<NearestFacility> getNearestAirport(double longitude, double latitude);
        [[nodiscard]] std::shared_ptr<std::vector<std::shared_ptr<NearestFacility>>> getNearestWaypoints(double longitude, double latitude, int maxCount = 5);
        [[nodiscard]] std::shared_ptr<NearestFacility> getNearestWaypoint(double longitude, double latitude);
        [[nodiscard]] std::shared_ptr<NearestFacility> getNearestVorNdb(double longitude, double latitude);

        void enableNearest(SIMCONNECT_FACILITY_LIST_TYPE facilityType = SIMCONNECT_FACILITY_LIST_TYPE_AIRPORT);
        void disableNearest(SIMCONNECT_FACILITY_LIST_TYPE facilityType = SIMCONNECT_FACILITY_LIST_TYPE_AIRPORT);

    private:
        [[nodiscard]] static std::shared_ptr<NearestFacility> getNearest(const std::vector<std::shared_ptr<NearestFacilityCacheEntry>>& collection, double longitude, double latitude);
        [[nodiscard]] static std::shared_ptr<std::vector<std::shared_ptr<NearestFacility>>> getNearest( const std::vector<std::shared_ptr<NearestFacilityCacheEntry>>& collection, double longitude, double latitude, int maxCount);
        static void processNearest(const std::shared_ptr<NearestFacilityRecord>& nfr, const SIMCONNECT_RECV_AIRPORT_LIST* data);
        static void processNearest(const std::shared_ptr<NearestFacilityRecord>& nfr, const SIMCONNECT_RECV_VOR_LIST* data);
        static void processNearest(const std::shared_ptr<NearestFacilityRecord>& nfr, const SIMCONNECT_RECV_WAYPOINT_LIST* data);

        HANDLE _simConnect;
        std::shared_ptr<FacilitySubscriptionBuilder> _facilitySubscriptionBuilder;
        std::unordered_map<SIMCONNECT_FACILITY_LIST_TYPE, std::shared_ptr<NearestFacilityRecord>> _nearestDefinitions = std::unordered_map<SIMCONNECT_FACILITY_LIST_TYPE, std::shared_ptr<NearestFacilityRecord>>();
    };
}
