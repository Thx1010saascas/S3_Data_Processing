#pragma once
#include <functional>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct FacilityDefinition
    {
        explicit FacilityDefinition(HANDLE simConnect, DWORD defineId);

        [[nodiscard]] DWORD defineId() const { return _defineId; }
        [[nodiscard]] DWORD requestId() const { return _requestId; }
        [[nodiscard]] std::function<void(const SIMCONNECT_RECV_FACILITY_DATA*)>& dataReceivedCallback();
        [[nodiscard]] std::function<void(DWORD)>& dataCompleteCallback();
        FacilityDefinition* add(const char* fieldName);
        FacilityDefinition* setDataReceivedCallback(const std::function<void(const SIMCONNECT_RECV_FACILITY_DATA*)>& callback);
        FacilityDefinition* setDataCompleteCallback(const std::function<void(DWORD requestId)>& callback);
        void request(DWORD requestId, const char* icao, const char* region = "") const;

    private:
        HANDLE _simConnect;
        mutable DWORD _defineId = 0;
        mutable DWORD _requestId = 0;
        std::function<void(const SIMCONNECT_RECV_FACILITY_DATA*)> _dataReceivedCallback;
        std::function<void(DWORD requestId)> _dataCompleteCallback;
    };
}
