#pragma once
#include <functional>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct DataDefinition {
        explicit DataDefinition(HANDLE simConnect, DWORD defineId);

        [[nodiscard]] DWORD defineId() const { return _defineId; }
        [[nodiscard]] std::function<void(const SIMCONNECT_RECV_SIMOBJECT_DATA*)>& callback();
        DataDefinition* add(const char* datumName, const char* unitsName, SIMCONNECT_DATATYPE dataType, float epsilon = 0);
        DataDefinition* addTagged(const char* datumName, const char* unitsName, SIMCONNECT_DATATYPE dataType, DWORD datumId, float epsilon = 0);
        DataDefinition* setCallback(const std::function<void(const SIMCONNECT_RECV_SIMOBJECT_DATA*)>& callback);
        void request(DWORD requestId, SIMCONNECT_PERIOD period = SIMCONNECT_PERIOD_SECOND, SIMCONNECT_DATA_REQUEST_FLAG flags = 0, DWORD periodOrigin = 0, DWORD periodInterval = 0, DWORD periodLimit = 0, DWORD objectId = SIMCONNECT_OBJECT_ID_USER) const;
        void request(DWORD defineId, DWORD requestId, SIMCONNECT_PERIOD period = SIMCONNECT_PERIOD_SECOND, SIMCONNECT_DATA_REQUEST_FLAG flags = 0, DWORD periodOrigin = 0, DWORD periodInterval = 0, DWORD periodLimit = 0, DWORD objectId = SIMCONNECT_OBJECT_ID_USER) const;

        void pause() const;
        void resume(DWORD periodInterval = 0) const;

    private:
        HANDLE _simConnect;
        mutable DWORD _defineId = 0;
        mutable DWORD _requestId = 0;
        mutable SIMCONNECT_PERIOD _period = SIMCONNECT_PERIOD_NEVER;
        mutable SIMCONNECT_DATA_REQUEST_FLAG _flags = 0;
        mutable DWORD _periodOrigin = 0;
        mutable DWORD _periodInterval = 0;
        mutable DWORD _periodLimit = 0;
        mutable DWORD _objectId = SIMCONNECT_OBJECT_ID_USER;
        std::function<void(const SIMCONNECT_RECV_SIMOBJECT_DATA*)> _callback;
    };
}
