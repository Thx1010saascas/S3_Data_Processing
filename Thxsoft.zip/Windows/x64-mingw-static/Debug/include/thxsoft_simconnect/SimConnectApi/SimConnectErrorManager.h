#pragma once
#include <vector>
#include <memory>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct SendIdRecord
    {
        DWORD sendId;
        std::string call;
    };

    struct SimConnectErrorManager
    {
        static void init(HANDLE simConnect);
        static void addSendRecord(const std::string& call);
        static std::string findSendRecord(DWORD id);

    private:
        static HANDLE _simConnect;
        static std::vector<std::shared_ptr<SendIdRecord>> _sendIds;
    };
}