#pragma once
#include <vector>
#include "DataDefinition.h"
#include "EventDefinitionBuilder.h"
#include "FacilityDefinition.h"
#include "FacilitySubscriptionBuilder.h"
#include "NearestFacilityProvider.h"

namespace thxsoft::simconnect
{
    struct SimConnectBuilder
    {
        explicit SimConnectBuilder(HANDLE simConnect,
            std::vector<std::shared_ptr<EventDefinition>>& eventDefinitions,
            std::vector<std::shared_ptr<DataDefinition>>& dataDefinitions,
            std::vector<std::shared_ptr<FacilityDefinition>>& facilityDefinitions,
            std::vector<std::shared_ptr<FacSubDefinition>>& facSubDefinitions);

        void eraseDataDefinition(DWORD defineId) const;
        [[nodiscard]] FacilitySubscriptionBuilder* subscribeToFacilities() const;
        [[nodiscard]] EventDefinitionBuilder* subscribeToEvents() const;
        [[nodiscard]] DataDefinition* makeDataDefinition(DWORD defineId) const;
        [[nodiscard]] FacilityDefinition* makeFacilityDefinition(DWORD defineId) const;
        [[nodiscard]] NearestFacilityProvider* nearestFacilityProvider() const;

    private:
        HANDLE _simConnect;
        std::shared_ptr<NearestFacilityProvider> _nearestFacilityProvider;
        std::shared_ptr<FacilitySubscriptionBuilder> _facilitySubscriptionBuilder;
        std::shared_ptr<EventDefinitionBuilder> _eventDefinitionBuilder;
        std::vector<std::shared_ptr<DataDefinition>>& _dataDefinitions;
        std::vector<std::shared_ptr<FacilityDefinition>>& _facilityDefinitions;
    };
}
