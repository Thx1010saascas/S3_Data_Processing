﻿#pragma once
#include <string>
#include <thread>
#include "SimConnectBuilder.h"
#include "SystemStateDefinition.h"

namespace thxsoft::simconnect
{
    class SimConnectHandler
    {
    public:
        explicit SimConnectHandler(std::string simConnectName, int tickRateMs);
        virtual ~SimConnectHandler();

        // Start SimConnect processing.
        [[nodiscard]] std::thread start();
        [[nodiscard]]bool isRunning() const;
        void stop();

        // Returns true if the API is processing normally.
        [[nodiscard]] bool isValid() const;

        // Get the SimConnect handle.
        [[nodiscard]] HANDLE getSimConnect() const;

        // Subscribe to facilities information.
        void unsubscribeToFacilities(SIMCONNECT_FACILITY_LIST_TYPE facilityType);

        // Subscribe to sim events.
        void unsubscribeToEvents(DWORD eventId);

        // Erase a data definition if it is no longer required.
        void eraseDataDefinition(DWORD defineId);

        // Get the current SimConnect state.
        void getSystemState(DWORD requestId, const char* state, const std::function<void(const SIMCONNECT_RECV_SYSTEM_STATE*)>& cb);

    protected:
        virtual void onInitialise(const SimConnectBuilder& builder) = 0;
        virtual void onStarted() {};
        virtual void onTimerTick() {};
        virtual void onConnectionChanged() { }
        virtual void onError(const std::string& exceptionMessage, const std::string& details, const SIMCONNECT_RECV_EXCEPTION* simConnectEx, bool restartingSimConnect) {}

private:
        void sendError(const std::string& exceptionMessage, const std::string& details, const SIMCONNECT_RECV_EXCEPTION* simConnectEx = nullptr);
        std::atomic<bool> _isValid = false;
        std::atomic<bool> _stop = false;
        std::atomic<bool> _isRunning = false;
        HANDLE  _simConnect = nullptr;
        int _tickRateMs;
        std::string _simConnectName;
        std::vector<std::shared_ptr<EventDefinition>> _eventDefinitions;
        std::vector<std::shared_ptr<DataDefinition>> _dataDefinitions;
        std::vector<std::shared_ptr<FacilityDefinition>> _facilityDefinitions;
        std::vector<std::shared_ptr<FacSubDefinition>> _facSubDefinitions;
        std::vector<std::shared_ptr<SystemStateDefinition>> _systemStateDefinition;

        void clear();
        void dispose();
        void dispatch();
        void doConnectionChanged();
    };
}