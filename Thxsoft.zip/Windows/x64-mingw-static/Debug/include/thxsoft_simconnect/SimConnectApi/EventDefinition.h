#pragma once
#include <functional>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>

namespace thxsoft::simconnect
{
    struct EventDefinition
    {
        explicit EventDefinition(const DWORD eventId, const char* datumName, std::function<void(const SIMCONNECT_RECV_EVENT*)> callback)
            : _eventId(eventId), _eventName(datumName), _callback(std::move(callback)) { }

        [[nodiscard]] DWORD eventId() const;
        [[nodiscard]] std::function<void(const SIMCONNECT_RECV_EVENT*)>& callback();
        [[nodiscard]] const char* eventName() const;
        void setCallback(const std::function<void(const SIMCONNECT_RECV_EVENT*)>& cb);

    private:
        DWORD _eventId;
        const char* _eventName;
        std::function<void(const SIMCONNECT_RECV_EVENT*)> _callback;
    };
};
