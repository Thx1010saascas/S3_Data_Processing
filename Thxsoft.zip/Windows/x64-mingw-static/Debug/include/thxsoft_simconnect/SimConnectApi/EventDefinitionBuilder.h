#pragma once
#include <memory>
#include "EventDefinition.h"

namespace thxsoft::simconnect
{
    struct EventDefinitionBuilder {
        explicit EventDefinitionBuilder(HANDLE simConnect, std::vector<std::shared_ptr<EventDefinition>>& eventDefinitions);

        EventDefinitionBuilder* setCallback(const std::function<void(const SIMCONNECT_RECV_EVENT*)>& callback);
        EventDefinitionBuilder* add(DWORD eventId, const char* eventName);
        void subscribe();

    private:
        HANDLE _simConnect;
        std::vector<std::shared_ptr<EventDefinition>>& _eventDefinitions;
    };
}
