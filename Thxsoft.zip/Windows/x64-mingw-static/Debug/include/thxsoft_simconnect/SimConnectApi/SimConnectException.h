#pragma once
#include <string>
#ifdef WIN32
#include <windows.h>
#else
#include <IntSafe.h>
#endif
#include <SimConnect.h>
#include <stdexcept>

namespace thxsoft::simconnect
{
    class SimConnectException final : public std::runtime_error
    {
    public:
        static std::string getSimConnectErrorText(const SIMCONNECT_RECV_EXCEPTION* simConnectEx);

        explicit SimConnectException(std::string message);
        explicit SimConnectException(const char* message);
    };
}
