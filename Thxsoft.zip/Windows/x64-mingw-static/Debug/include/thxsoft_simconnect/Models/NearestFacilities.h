#pragma once
#include <string>

struct NearestFacility
{
    std::string ident;
    std::string region;
    double altitude = 0;
    double longitude = 0;
    double latitude = 0;
    double distance = 0;
};

