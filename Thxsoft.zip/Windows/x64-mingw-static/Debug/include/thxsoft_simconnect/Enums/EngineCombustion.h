﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct EngineCombustion
    {
        enum EngineCombustions
        {
            None = 0,
            Engine1 = 1,
            Engine2 = 2,
            Engine3 = 4,
            Engine4 = 8
        };

        static std::string toString(const EngineCombustions v)
        {
            switch(v)
            {
            case None:  return "None";
            case Engine1:    return "Engine 1";
            case Engine2:    return "Engine 2";
            case Engine3:    return "Engine 3";
            case Engine4:    return "Engine 4";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid EngineCombustionss enum.", static_cast<int>(v)));
        }
    };
}