﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct RunwayNumber
    {
        enum RunwayNumbers
        {
            None,
            One,
            Two,
            Three,
            Four,
            Five,
            Six,
            Seven,
            Eight,
            Nine,
            Ten,
            Eleven,
            Twelve,
            Thirteen,
            Fourteen,
            Fifteen,
            Sixteen,
            Seventeen,
            Eighteen,
            Nineteen,
            Twenty,
            TwentyOne,
            TwentyTwo,
            TwentyThree,
            TwentyFour,
            TwentyFive,
            TwentySix,
            TwentySeven,
            TwentyEight,
            TwentyNine,
            Thirty,
            ThirtyOne,
            ThirtyTwo,
            ThirtyThree,
            ThirtyFour,
            ThirtyFive,
            ThirtySix,
            North,
            NorthEast,
            East,
            SouthEast,
            South,
            SouthWest,
            West,
            NorthWest,
            Last
        };

        static std::string toString(const RunwayNumbers v)
        {
            switch(v)
            {
            case None: return "None";
            case One: return "01";
            case Two: return "02";
            case Three: return "03";
            case Four: return "04";
            case Five: return "05";
            case Six: return "06";
            case Seven: return "07";
            case Eight: return "08";
            case Nine: return "09";
            case Ten: return "100";
            case Eleven: return "110";
            case Twelve: return "120";
            case Thirteen: return "130";
            case Fourteen: return "140";
            case Fifteen: return "150";
            case Sixteen: return "160";
            case Seventeen: return "170";
            case Eighteen: return "180";
            case Nineteen: return "190";
            case Twenty: return "200";
            case TwentyOne: return "210";
            case TwentyTwo: return "220";
            case TwentyThree: return "230";
            case TwentyFour: return "240";
            case TwentyFive: return "250";
            case TwentySix: return "260";
            case TwentySeven: return "270";
            case TwentyEight: return "280";
            case TwentyNine: return "290";
            case Thirty: return "300";
            case ThirtyOne: return "310";
            case ThirtyTwo: return "320";
            case ThirtyThree: return "330";
            case ThirtyFour: return "340";
            case ThirtyFive: return "350";
            case ThirtySix: return "360";
            case North: return "North";
            case NorthEast: return "North East";
            case East: return "East";
            case SouthEast: return "South East";
            case South: return "South";
            case SouthWest: return "South West";
            case West: return "West";
            case NorthWest: return "North West";
            case Last: return "Last";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid RunwayNumbers enum.", static_cast<int>(v)));
        }
    };
}
