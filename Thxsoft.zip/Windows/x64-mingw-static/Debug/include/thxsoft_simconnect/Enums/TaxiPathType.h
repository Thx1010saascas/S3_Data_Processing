﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct TaxiPathType
    {
        enum TaxiPathTypes
        {
            None,
            Taxi,
            Runway,
            Parking,
            Path,
            Closed,
            Vehicle,
            Road,
            PaintedLine
        };

        static std::string toString(const TaxiPathTypes v)
        {
            switch (v)
            {
            case None: return "None";
            case Taxi: return "Taxi";
            case Runway: return "Runway";
            case Parking: return "Parking";
            case Path: return "Path";
            case Closed: return "Closed";
            case Vehicle: return "Vehicle";
            case Road: return "Road";
            case PaintedLine: return "Painted Line";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid TaxiPathTypes enum.", static_cast<int>(v)));
        }
    };
}
