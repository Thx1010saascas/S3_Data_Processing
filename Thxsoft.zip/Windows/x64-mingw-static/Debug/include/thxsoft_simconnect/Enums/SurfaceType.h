﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct SurfaceType
    {
        enum SurfaceTypes
        {
            Concrete,
            Grass,
            WaterFsx,
            GrassBumpy,
            Asphalt,
            ShortGrass,
            LongGrass,
            HardTurf,
            Snow,
            Ice,
            Urban,
            Forest,
            Dirt,
            Coral,
            Gravel,
            OilTreated,
            SteelMats,
            Bituminus,
            Brick,
            Macadam,
            Planks,
            Sand,
            Shale,
            Tarmac,
            WrightFlyerTrack,
            Ocean,
            Water,
            Pond,
            Lake,
            River,
            WasteWater,
            Paint,
            Unknown  = 254,
            Undefined = 255
        };

        static std::string toString(const SurfaceTypes v)
        {
            switch(v)
            {
            case Concrete:  return "Concrete";
            case Grass:  return "Grass";
            case WaterFsx:  return "Water";
            case GrassBumpy:  return "Grass Bumpy";
            case Asphalt:  return "Asphalt";
            case ShortGrass:  return "Short Grass";
            case LongGrass:  return "Long Grass";
            case HardTurf:  return "Hard Turf";
            case Snow:  return "Snow";
            case Ice:  return "Ice";
            case Urban:  return "Urban";
            case Forest:  return "Forest";
            case Dirt:  return "Dirt";
            case Coral:  return "Coral";
            case Gravel:  return "Gravel";
            case OilTreated:  return "Oil Treated";
            case SteelMats:  return "Steel Mats";
            case Bituminus:  return "Bitumin";
            case Brick:  return "Brick";
            case Macadam:  return "Macadam";
            case Planks:  return "Planks";
            case Sand:  return "Sand";
            case Shale:  return "Shale";
            case Tarmac:  return "Tarmac";
            case WrightFlyerTrack:  return "Wright Flyer Track";
            case Ocean:  return "Ocean";
            case Water:  return "Water";
            case Pond:  return "Pond";
            case Lake:  return "Lake";
            case River:  return "River";
            case WasteWater:  return "Waste Water";
            case Paint:  return "Paint";
            case Unknown:  return "Unknown";
            case Undefined:  return "Undefined";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid SurfaceTypes enum.", static_cast<int>(v)));
        }
    };
}