﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct HelipadType
    {
        enum HelipadTypes
        {
            Home,
            H,
            Square,
            Circle,
            Medical
        };

        static std::string toString(const HelipadTypes v)
        {
            switch(v)
            {
            case Home:  return "Home";
            case H:    return "H";
            case Square:    return "Square";
            case Circle:    return "Circle";
            case Medical:    return "Medical";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid HelipadTypes enum.", static_cast<int>(v)));
        }
    };
}