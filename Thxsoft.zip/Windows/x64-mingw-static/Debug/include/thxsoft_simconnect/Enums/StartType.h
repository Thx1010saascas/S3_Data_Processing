﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct StartType
    {
        enum StartTypes
        {
            Unknown,
            Runway,
            Water,
            Helipad,
            Track
        };

        static std::string toString(const StartTypes v)
        {
            switch(v)
            {
            case Unknown:  return "Unknown";
            case Runway:    return "Runway";
            case Water:    return "Water";
            case Helipad:    return "Helipad";
            case Track:    return "Track";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid StartTypes enum.", static_cast<int>(v)));
        }
    };
}