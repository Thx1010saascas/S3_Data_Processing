﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct TaxiPointType
    {
        enum TaxiPointTypes
        {
            None,
            Normal,
            HoldShort,
            IlsHoldShort,
            HoldShortNoDraw,
            IlsHoldShortNoDraw
        };

        static std::string toString(const TaxiPointTypes v)
        {
            switch(v)
            {
            case None:  return "None";
            case Normal:    return "Normal";
            case HoldShort:    return "Hold Short";
            case IlsHoldShort:    return "ILS Hold Short";
            case HoldShortNoDraw:    return "Hold Short No Draw";
            case IlsHoldShortNoDraw:    return "Hold Short ILS No Draw";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid TaxiPointTypes enum.", static_cast<int>(v)));
        }
    };
}