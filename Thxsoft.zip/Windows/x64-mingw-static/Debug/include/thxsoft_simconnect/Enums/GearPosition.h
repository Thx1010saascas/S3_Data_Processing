﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct GearPosition
    {
        enum GearPositions
        {
            Unknown,
            Up,
            Down
        };

        static std::string toString(const GearPositions v)
        {
            switch(v)
            {
            case Unknown:   return "Unknown";
            case Up:        return "Up";
            case Down:      return "Down";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid GearPosition enum.", static_cast<int>(v)));
        }
    };
}