﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct MagnetoProp
    {
        enum MagnetoProps
        {
            Off = 0,
            Right = 1,
            Left = 2,
            Both = 3,
            Start = 4
        };

        static std::string toString(const MagnetoProps v)
        {
            switch(v)
            {
            case MagnetoProps::Off:       return "Off";
            case MagnetoProps::Right:     return "Right";
            case MagnetoProps::Left:      return "Left";
            case MagnetoProps::Both:      return "Both";
            case MagnetoProps::Start:    return "Start";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid MagnetoProps enum.", static_cast<int>(v)));
        }
    };

    struct MagnetoJet
    {
        enum MagnetoJets
        {
            Off = 0,
            Start = 1,
            Gen = 2
        };

        static std::string toString(const MagnetoJets v)
        {
            switch(v)
            {
            case MagnetoJets::Off:  return "Off";
            case MagnetoJets::Start:    return "Start";
            case MagnetoJets::Gen:    return "Gen";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid MagnetoJets enum.", static_cast<int>(v)));
        }
    };
}
