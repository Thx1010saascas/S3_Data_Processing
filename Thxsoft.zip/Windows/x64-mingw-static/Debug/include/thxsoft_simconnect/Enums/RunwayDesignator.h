﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct RunwayDesignator
    {
        enum RunwayDesignators
        {
            None,
            Left,
            Right,
            Center,
            Water,
            A,
            B,
            Last
        };

        static std::string toString(const RunwayDesignators v)
        {
            switch(v)
            {
            case None: return "None";
            case Left: return "LEft";
            case Right: return "Right";
            case Center: return "Center";
            case Water: return "Water";
            case A: return "A";
            case B: return "B";
            case Last: return "Last";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid RunwayDesignators enum.", static_cast<int>(v)));
        }
    };
}
