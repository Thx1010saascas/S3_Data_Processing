﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct NearestPositionCategory
    {
        enum NearestPositionCategories
        {
            Unknown = 0,
            Airport = 1,
            City = 2,
            Landmark = 3,
            Fauna = 4
        };

        static std::string toString(const NearestPositionCategories v)
        {
            switch(v)
            {
            case Unknown:  return "Unknown";
            case Airport:    return "Airport";
            case City:    return "City";
            case Landmark:    return "Landmark";
            case Fauna:    return "Fauna";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid NearestPositionCategories enum.", static_cast<int>(v)));
        }
    };
}