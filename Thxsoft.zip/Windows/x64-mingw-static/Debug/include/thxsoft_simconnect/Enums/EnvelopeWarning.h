﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct EnvelopeWarning
    {
        enum EnvelopeWarnings
        {
            None = 0,
            Crashed = 1,
            OverSpeed = 2,
            Stall = 3
        };

        static std::string toString(const EnvelopeWarnings v)
        {
            switch(v)
            {
            case None:  return "NBone";
            case Crashed:    return "Crashed";
            case OverSpeed:    return "OverSpeed";
            case Stall:    return "Stall";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid EnvelopeWarnings enum.", static_cast<int>(v)));
        }
    };
}
