﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct Light
    {
        enum Lights
        {
            None = 0,
            Nav = 1,
            Beacon = 2,
            Landing = 4,
            Taxi = 8,
            Strobe = 16,
            Recognition = 32
        };

        static std::string toString(const Lights v)
        {
            switch(v)
            {
            case None:  return "None";
            case Nav:    return "Nav";
            case Beacon:    return "Beacon";
            case Landing:    return "Landing";
            case Taxi:    return "Taxi";
            case Strobe:    return "Strobe";
            case Recognition:    return "Recognition";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid Lights enum.", static_cast<int>(v)));
        }
    };
}
