﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct ApproachLegType
    {
        enum ApproachLegTypes
        {
            Unknown,
            AF,
            CA,
            CD,
            CF,
            CI,
            CR,
            DF,
            FA,
            FC,
            FD,
            FM,
            HA,
            HF,
            HM,
            IF,
            PT,
            RF,
            TF,
            VA,
            VD,
            VI,
            VM,
            VR
        };

        static std::string toString(const ApproachLegTypes v)
        {
            switch(v)
            {
            case Unknown:  return "Unknown";
            case AF:    return "DME Arc to Fix";
            case CA:    return "Course to Altitude";
            case CD:    return "Course to DMA Distance";
            case CF:    return "Course to Fix";
            case CI:    return "Course to Intercept";
            case CR:    return "Course to Radial";
            case DF:    return "Direct to Fix";
            case FA:    return "Fix to Altitude";
            case FC:    return "Track from Fix";
            case FD:    return "Track from Fix to DME Distance";
            case FM:    return "Track from Fix to Manual Terminator";
            case HA:    return "Racetrack Course Reversal to Altitude";
            case HF:    return "Racetrack Course Reversal to Fix";
            case HM:    return "Racetrack Course Reversal to Manual Terminator";
            case IF:    return "Initial Fix";
            case PT:    return "Procedure Turn";
            case RF:    return "Constant Radius Arc";
            case TF:    return "Track to Fix";
            case VA:    return "Heading to Altitude";
            case VD:    return "Heading to DME Distance";
            case VI:    return "Heading to Intercept";
            case VM:    return "Heading to Manual Termination";
            case VR:    return "Heading to Radial";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid ApproachLegTypes enum.", static_cast<int>(v)));
        }
    };
}