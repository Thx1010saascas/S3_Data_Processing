﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct Orientation
    {
        enum Orientations
        {
            Forward,
            Reverse
        };

        static std::string toString(const Orientations v)
        {
            switch(v)
            {
            case Forward:  return "Forward";
            case Reverse:    return "Reverse";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid Orientations enum.", static_cast<int>(v)));
        }
    };
}