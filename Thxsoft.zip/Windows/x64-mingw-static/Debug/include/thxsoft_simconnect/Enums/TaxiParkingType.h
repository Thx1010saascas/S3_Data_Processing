﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct TaxiParkingType
    {
        enum TaxiParkingTypes
        {
            None,
            RampGa,
            RampGaSmall,
            RampGaMedium,
            RampGaLarge,
            RampCargo,
            RampMlCargo,
            RampMilCombat,
            GateSmall,
            GateMedium,
            GateHeavy,
            DockGa,
            Fuel,
            Vehicle,
            RampGaExtra,
            GateExtra
        };

        static std::string toString(const TaxiParkingTypes v)
        {
            switch(v)
            {
            case None:  return "None";
            case RampGa:    return "Ramp GA";
            case RampGaSmall:    return "Ramp GA Small";
            case RampGaMedium:    return "Ramp GA Medium";
            case RampGaLarge:    return "Ramp GA Large";
            case RampCargo:    return "Ramp Cargo";
            case RampMlCargo:    return "Ramp Military Cargo";
            case RampMilCombat:    return "Ramp Military Combat";
            case GateSmall:    return "Gate Small";
            case GateMedium:    return "Gate Medium";
            case GateHeavy:    return "Gate Heavy";
            case DockGa:    return "Dock GA";
            case Fuel:    return "Fuel";
            case Vehicle:    return "Vehicle";
            case RampGaExtra:    return "Ramp GA Extra";
            case GateExtra:    return "Gate Extra";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid TaxiParkingTypes enum.", static_cast<int>(v)));
        }
    };
}