﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct TaxiPathEdgeType
    {
        enum TaxiPathEdgeTypes
        {
            None,
            Solid,
            Dashed,
            SolidDashed
        };

        static std::string toString(const TaxiPathEdgeTypes v)
        {
            switch(v)
            {
            case None:  return "None";
            case Solid:    return "Solid";
            case Dashed:    return "Dashed";
            case SolidDashed:    return "Solid Dashed";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid TaxiPathEdgeType enum.", static_cast<int>(v)));
        }
    };
}