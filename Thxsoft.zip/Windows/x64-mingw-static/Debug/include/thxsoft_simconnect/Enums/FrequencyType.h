﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct FrequencyType
    {
        enum FrequencyTypes
        {
            None,
            Multicom,
            Unicom,
            Ground,
            Tower,
            Approach,
            Departure,
            Center,
            Fss,
            Awos,
            Asos,
            ClearancePreTaxi,
            RemoteClearanceDelivery
        };

        static std::string toString(const FrequencyTypes v)
        {
            switch (v)
            {
            case None: return "None";
            case Multicom: return "Multicom";
            case Unicom: return "Unicom";
            case Ground: return "Ground";
            case Tower: return "Tower";
            case Approach: return "Approach";
            case Departure: return "Departure";
            case Center: return "Center";
            case Fss: return "FSS";
            case Awos: return "AWOS";
            case Asos: return "ASOS";
            case ClearancePreTaxi: return "Clearance Pre-Taxi";
            case RemoteClearanceDelivery: return "Remote Clearance Delivery";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid FrequencyTypes enum.", static_cast<int>(v)));
        }
    };
}
