﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct TurnDirection
    {
        enum TurnDirections
        {
            None,
            Left,
            Right,
            Either
        };

        static std::string toString(const TurnDirections v)
        {
            switch(v)
            {
            case None:  return "None";
            case Left:    return "Left";
            case Right:    return "Right";
            case Either:    return "Either";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid TurnDirections enum.", static_cast<int>(v)));
        }
    };
}