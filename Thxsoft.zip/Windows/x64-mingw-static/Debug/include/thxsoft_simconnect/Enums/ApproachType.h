﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct ApproachType
    {
        enum ApproachTypes
        {
            Undefined,
            Gps,
            Vor,
            Ndb,
            Ils,
            Localizer,
            Sdf,
            Lda,
            VorDme,
            NdbDme,
            Rnav,
            LocalizerBackcourse
        };

        static std::string toString(const ApproachTypes v)
        {
            switch(v)
            {
            case Undefined: return "Undefined";
            case Gps:     return "GPS";
            case Vor:     return "VOR";
            case Ndb:     return "NDB";
            case Ils:     return "ILS";
            case Localizer: return "Localizer";
            case Sdf:     return "SDF";
            case Lda:     return "LDA";
            case VorDme:  return "VOR/DME";
            case NdbDme:  return "NDB/DME";
            case Rnav:    return "RNAV";
            case LocalizerBackcourse: return "Localizer Backcourse";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid ApproachTypes enum.", static_cast<int>(v)));
        }
    };
}