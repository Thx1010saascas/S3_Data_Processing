﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    enum AltitudeDescriptions
    {
        NotUsed,
        At,
        AtOrAbove,
        AtOrBelow,
        InBetween
    };

    struct AltitudeDescription
    {
        static std::string toString(const AltitudeDescriptions v)
        {
            switch(v)
            {
            case NotUsed:  return "Not Used";
            case At:    return "At";
            case AtOrAbove:    return "At or Above";
            case AtOrBelow:    return "At or Below";
            case InBetween:    return "In Between";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid AltitudeDescriptions enum.", toString(v)));
        }
    };
}