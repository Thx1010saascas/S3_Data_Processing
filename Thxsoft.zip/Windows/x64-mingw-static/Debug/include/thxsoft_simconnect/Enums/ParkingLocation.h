﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct ParkingLocation
    {
        enum ParkingLocations
        {
            None,
            Parking,
            N,
            Ne,
            E,
            Se,
            S,
            Sw,
            W,
            Nw,
            Gate,
            Dock,
            GateA,
            GateB,
            GateC,
            GateD,
            GateE,
            GateF,
            GateG,
            GateH,
            GateI,
            GateJ,
            GateK,
            GateL,
            GateM,
            GateN,
            GateO,
            GateP,
            GateQ,
            GateR,
            GateS,
            GateT,
            GateU,
            GateV,
            GateW,
            GateX,
            GateY,
            GateZ
        };

        static std::string toString(const ParkingLocations v)
        {
            switch(v)
            {
            case None:  return "None";
            case Parking:  return "Parking";
            case N:  return "North Parking";
            case Ne:  return "North East Parking";
            case E:  return "East Parking";
            case Se:  return "South East Parking";
            case S:  return "South Parking";
            case Sw:  return "South West Parking";
            case W:  return "West Parking";
            case Nw:  return "North West Parking";
            case Gate:  return "Gate";
            case Dock:  return "Dock";
            case GateA:  return "Gate A";
            case GateB:  return "Gate B";
            case GateC:  return "Gate C";
            case GateD:  return "Gate D";
            case GateE:  return "Gate E";
            case GateF:  return "Gate F";
            case GateG:  return "Gate G";
            case GateH:  return "Gate H";
            case GateI:  return "Gate I";
            case GateJ:  return "Gate J";
            case GateK:  return "Gate K";
            case GateL:  return "Gate L";
            case GateM:  return "Gate M";
            case GateN:  return "Gate N";
            case GateO:  return "Gate O";
            case GateP:  return "Gate P";
            case GateQ:  return "Gate Q";
            case GateR:  return "Gate R";
            case GateS:  return "Gate S";
            case GateT:  return "Gate T";
            case GateU:  return "Gate U";
            case GateV:  return "Gate V";
            case GateW:  return "Gate W";
            case GateX:  return "Gate X";
            case GateY:  return "Gate Y";
            case GateZ:  return "Gate Z";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid ParkingLocations enum.", static_cast<int>(v)));
        }
    };
}