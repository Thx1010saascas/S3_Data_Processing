﻿#pragma once
#include <format>
#include <string>

namespace thxsoft::simconnect
{
    struct NavPositionType
    {
        enum NavPositionTypes
        {
            Airport = 65,
            Vor = 86,
            Ndb = 78,
            Waypoint = 87
        };

        static std::string toString(const NavPositionTypes v)
        {
            switch(v)
            {
            case Airport:  return "Airport";
            case Vor:    return "VOR";
            case Ndb:    return "NDB";
            case Waypoint:    return "Waypoint";
            }

            throw std::invalid_argument(std::format("'{}' is not a valid NavPositionTypes enum.", static_cast<int>(v)));
        }
    };
}