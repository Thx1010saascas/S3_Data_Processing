#pragma once

#include "thxsoft_database_sqlite/msqlite/error.hpp"
#include "thxsoft_database_sqlite/msqlite/throws/value_or_throw.hpp"

namespace msqlite::throws {

using error = ::msqlite::error;

}
