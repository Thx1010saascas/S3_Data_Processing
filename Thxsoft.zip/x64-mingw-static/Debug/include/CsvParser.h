#pragma once
#include <istream>
#include <string>
#include <unordered_map>
#include <vector>
#include <memory>
#include <optional>

using namespace std;

namespace thxsoft::common
{
    using namespace std;

    class CsvParser {
    public:
        explicit CsvParser(const string& data);
        explicit CsvParser(const shared_ptr<istream>& stream);

        [[nodiscard]]int lineNumber() const;
        void seekStart() const;
        void appendColumn(const string& name) const;
        [[nodiscard]]int getOrdinal(const string& columnName) const;
        [[nodiscard]]shared_ptr<vector<string>> getColumnNames() const;
        [[nodiscard]]shared_ptr<vector<string>> rawData() const;
        void setValue(const string& columnName, const string& value) const;
        void setValue(int ordinal, const string& value) const;

        [[nodiscard]]string getValue(const string& columnName) const;
        [[nodiscard]]optional<double> getValueAsDouble(const string& columnName) const;
        [[nodiscard]]optional<int> getValueAsInteger(const string& columnName) const;
        [[nodiscard]]optional<long long> getValueAsInt64(const string& columnName) const;
        [[nodiscard]]string getValue(int ordinal) const;
        [[nodiscard]]optional<double> getValueAsDouble(int ordinal) const;
        [[nodiscard]]optional<int> getValueAsInteger(int ordinal) const;
        [[nodiscard]]optional<long long> getValueAsInt64(int ordinal) const;
        bool readLine();

    private:
        void readHeader();
        optional<string> readRawLine() ;

        int _lineNumber;
        /// <summary>
        /// Defines a prefix to be used in Source column names to represent an index rather than a column name reference.
        /// </summary>
        const string ColumnReferenceByIndexPrefix = "###";

        const shared_ptr<istream> _stream;
        const shared_ptr<vector<string>> _manualColumns;
        const shared_ptr<vector<string>> _columnNames;
        const shared_ptr<unordered_map<string, int>> _columnNameIndexes;
        const shared_ptr<vector<string>> _rawData;
    };
}