#pragma once
#include <future>
#include <spdlog/spdlog.h>

using namespace std;

struct ConcurrentJob
{
    template<typename T>
    static void waitForThreadsToFinish(vector<future<T>>* tasks)
    {
        waitForAvailableThread(tasks, 0);
    }

    template<typename T>
    static void waitForAvailableThread(vector<future<T>>* tasks, const int maxThreadCount)
    {
        // ReSharper disable once CppDFALoopConditionNotUpdated
        while(tasks->size() >= maxThreadCount)
        {
            auto task = tasks->begin();
            while (task != tasks->end())
            {
                if(task->wait_for(chrono::milliseconds(1)) == future_status::timeout)
                    ++task;
                else
                    task = tasks->erase(task);
            }

            if(maxThreadCount == 0)
            {
                if(tasks->empty())
                    break;

                spdlog::info("Waiting for {} tasks to finish.", tasks->size());
            }

            this_thread::sleep_for(chrono::seconds(1));
        }
    }
};
