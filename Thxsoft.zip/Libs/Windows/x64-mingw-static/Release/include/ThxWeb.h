#pragma once
#include <string>
#include <curl/curl.h>

using namespace std;

struct ThxWeb {

    static string encodedUrl(CURL *curl, string url);

};
