#pragma once
#include <format>
#include <string>

using namespace std;

namespace thxsoft::database
{
    struct DatabaseUtils {
        static string makeDbColumnValue(const string& value);

        template <typename T, enable_if_t<is_integral_v<T>, int> = 0>
        static string asDbString(T value)
        {
            return format("{}", value);
        }
        template <typename T, enable_if_t<is_floating_point_v<T>, int> = 0>
        static string asDbString(T value)
        {
            return to_string(value);
        }
        template <typename T, enable_if_t<is_same_v<T,string>, int> = 0>
        static string asDbString(T value)
        {
            return makeDbColumnValue(value);
        }
        template <typename T, enable_if_t<is_pointer_v<T>, int> = 0>
        static string asDbString(T value)
        {
            if(value == nullptr)
                return "null";

            return to_string(*value);
        }
        template <typename T, enable_if_t<is_enum_v<T>, int> = 0>
        static string asDbString(T value)
        {
            return to_string(static_cast<int>(value));
        }
    };
}
