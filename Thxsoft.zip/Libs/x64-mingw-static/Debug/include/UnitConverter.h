#pragma once

namespace thxsoft::conversion
{
    static double metersToFeet(const double meters) { return meters * 3.280839895; }
    static double feetToMeters(const double feet) { return feet * 3.281; }
}