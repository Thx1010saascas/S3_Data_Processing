#pragma once
#include <optional>

namespace thxsoft::geo
{
    using namespace std;

    enum DistanceUnit
    {
        Feet,
        Meters
    };

    struct WindDirection
    {
        WindDirection(const int direction, const int speed) : direction(direction), speed(speed) { }
        const int direction;
        const int speed;
    };

    struct CrossWind
    {
        CrossWind(const int headwind, const int crosswind) : headwind(headwind), crosswind(crosswind) { }
        const int headwind;
        const int crosswind;
    };

    struct ThxGeo {
        #define PI              3.141592653589793238
        #define Degrees2Radians 0.017453292519943296
        #define Radians2Degrees 57.295779513082321

        static optional<CrossWind> getCrosswind(int aircraftHeading, const WindDirection& wind);
        static double distanceFast(double longitude, double latitude, double otherLongitude, double otherLatitude, const DistanceUnit& distanceUnit = Meters);
        static double distance(double longitude1, double latitude1, double longitude2, double latitude2);
        static double bearing(double bearing1, double bearing2);
        static double bearing(double longitude1, double latitude1, double longitude2, double latitude2);

    };

}
