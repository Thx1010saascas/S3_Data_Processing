#pragma once

struct BolometricCalculator {
    static double getCorrectionFactor(int teff);
};
