#pragma once
#include <utility>
#include "EventArgs.h"

namespace thxsoft::events
{
    class PropertyChangedEventArgs final : public EventArgs
    {
        std::string _propertyName;
        void* _value;
        bool _hasValue;

    public:
        explicit PropertyChangedEventArgs(const std::string& sender, std::string propertyName)
            : EventArgs(sender), _propertyName(std::move(propertyName)), _value(nullptr), _hasValue(false)
        {
        }

        ~PropertyChangedEventArgs() override
        = default;

        [[nodiscard]] std::string propertyName() const
        {
            return _propertyName;
        }

        [[nodiscard]] bool hasValue() const
        {
            return _hasValue;
        }

        template<typename T>
        void setValue(T* value)
        {
            _hasValue = (value != nullptr);
            _value = (void*)value;
        }

        template<typename T>
        [[nodiscard]] T value() const
        {
            return *static_cast<T*>(_value);
        }
};
}