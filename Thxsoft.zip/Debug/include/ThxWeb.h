#pragma once
#include <string>
#include <curlpp/cURLpp.hpp>
#include <curlpp/Easy.hpp>
#include <curlpp/Options.hpp>

using namespace std;

struct ThxWeb {

    static string encodedUrl(CURL *curl, string url);

};
