#pragma once
#include <string>
#include <vector>
#include <chrono>

using namespace std;

class Thx {

public:
    static string toLower(const string& text);
    static string toUpper(const string& text);
    static string toDurationString(const chrono::time_point<chrono::steady_clock>& startTime, bool shortLabels = false);
    static string toDurationString(double milliseconds, bool shortLabels = false);
    static string escapeSingleQuote(const string & original);
    static vector<string> split(const string &s, const string &delimiter = " ");
    static string trim(const string& in);
    static string replace(string s, const string_view& what, const string_view& with);
    static string deleteDuplicateSpaces(string& str);

private:
    static bool _bothAreSpaces(char lhs, char rhs);
    static string _replaceLonger(string s, const string_view& what, const string_view& with);
    static string _replaceNotLonger(string s, const string_view& what, const string_view& with);
};
