#pragma once

#if __has_include("tchar.h")
#include <tchar.h>

struct ProcessUtilities
{
    [[nodiscard]] static bool isAppRunning(const TCHAR* appName);
};
#endif