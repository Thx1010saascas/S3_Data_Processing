#pragma once
#include "Event.h"
#include "EventHandlerException.h"
#include "PropertyChangedEventArgs.h"
#include "Thx.h"

namespace thxsoft::events
{
    class NotifyPropertyChanged
    {
    public:
        virtual ~NotifyPropertyChanged() = default;
        [[nodiscard]] bool isModified() const { return _isModified; }
        void setIsUnmodified() { _isModified = false; }
        Event& events() { return _event; }

    protected:
        virtual const char* classTypeName()
        {
            throw EventHandlerException("Override ClassTypeName() with the name of the class type.");
        }

        template <typename T>
        void setField(T* field, const T& value, const char* callingFunction)
        {
            if ((field == nullptr) || (*field != value))
                _isModified = true;

            *field = value;

            OnPropertyChanged(callingFunction, field);
        }

        template <typename T>
        void setField(std::optional<T>& field, const std::optional<T>& value, const char* callingFunction)
        {
            if ((!field.has_value() && value.has_value()) || (field.has_value() && !value.has_value()) || (field.has_value() && field.value() != value.value()))
                _isModified = true;

            field = value;

            OnPropertyChanged(callingFunction, value.has_value() ? &value.value() : nullptr);
        }

        template <typename T>
        void OnPropertyChanged(const char* callingFunction, T* value)
        {
            const auto nsSplit = Thx::split(callingFunction, NsDelimiter);
            auto property = nsSplit[nsSplit.size() == 1 ? 0 : 1];

            if(property.starts_with("set"))
                property = property.substr(3);

            const auto args = std::make_shared<PropertyChangedEventArgs>(classTypeName(), property);

            args->setValue(value);

            _event(args);
        }

        Event _event;
        bool _isModified = false;
        const std::string NsDelimiter = "::";
    };
}