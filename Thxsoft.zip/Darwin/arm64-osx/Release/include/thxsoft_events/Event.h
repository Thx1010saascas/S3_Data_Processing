#pragma once
#include <vector>
#include <memory>
#include "EventHandler.h"

namespace thxsoft::events
{
    class Event
    {
    private:
        std::vector<std::unique_ptr<EventHandler>> _subscribed_handlers;

        void raiseEvent(const std::shared_ptr<EventArgs>& args);

    public:
        void addHandler(const EventHandler &handler);
        void removeHandler(const EventHandler &handler);

        void operator()(const std::shared_ptr<EventArgs>& args);
        Event &operator+=(const EventHandler &handler);
        Event &operator+=(const EventHandler::Func &handler);
        Event &operator-=(const EventHandler &handler);

        [[nodiscard]] size_t subscriberCount() const { return _subscribed_handlers.size(); }
    };
}